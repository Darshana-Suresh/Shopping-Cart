'use strict';

describe('Controller: MainCtrl', function () {

  // load the controller's module
  beforeEach(module('newappApp'));

  var MainCtrl,scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    MainCtrl = $controller('MainCtrl', {$scope: scope /* place here mocked dependencies*/});
  }));

  it('should add an item',function(){
          //  scope.products=["eggs"];
            var oldLength=scope.products.length;
            scope.productName="milk";
            scope.addProduct();
            expect(scope.products.length).toBe(oldLength+1);
  });
  it('should delete an item',function(){
    scope.products=["milk","eggs","peas"];
    scope.removeProduct(1);
    expect(scope.products).toEqual(["milk","peas"]);
  });
  it('should not add an empty item',function(){
    scope.products=["milk","eggs"];
    scope.productName="";
    scope.addProduct();
    expect(scope.products).toEqual(["milk","eggs"]);
  });
  it('should not add an existing item',function(){
    scope.productName="milk";
    scope.products=["eggs","milk","peas"];
    scope.addProduct();
    expect(scope.products).toEqual(["eggs","milk","peas"]);
  });
});
