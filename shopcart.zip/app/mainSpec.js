'use strict';

describe('Controller: MainCtrl', function () {
        
    beforeEach(module('newappApp'));

    var MainCtrl,
        scope;
    beforeEach(inject(function($controller,$scope){
    scope = $scope.$new();
    MainCtrl = $controller('MainCtrl', {
      $scope: scope
      // place here mocked dependencies
    });    }));

    describe('check all functionalities',function(){
        it('should add an item',function(){
            var $scope={};
            var controller = $controller('MainCtrl',{$scope:$scope});
            $scope.products=[];
            $scope.productName="milk";
            $scope.addProduct();
            expect($scope.products.length).toBe(1);
        });
    });
});    